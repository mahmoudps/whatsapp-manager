import { afterAll, beforeAll, expect, test } from '@jest/globals';

let db: any;

beforeAll(async () => {
  process.env.DATABASE_PATH = ':memory:';
  process.env.ADMIN_USERNAME = `test_admin_${Date.now()}`;
  const dbModule = await import('../lib/database');
  db = dbModule.db;
  await dbModule.initializeDatabase();
});

afterAll(() => {
  if (db) db.close();
});

test('createDevice inserts a new device', async () => {
  const device = await db.createDevice('Test Device');
  expect(device).toBeDefined();
  expect(device.name).toBe('Test Device');
  expect(device.status).toBe('disconnected');
});

test('createMessage inserts a new message', async () => {
  const device = await db.createDevice('Message Device');
  const message = await db.createMessage({
    deviceId: device.id,
    recipient: '123456789',
    message: 'Hello',
    status: 'sent',
    messageType: 'text',
  });
  expect(message).toBeDefined();
  expect(message.deviceId).toBe(device.id);
  expect(message.message).toBe('Hello');
});

test('createAnalyticsEvent stores event and summary returns counts', async () => {
  const device = await db.createDevice('Analytics Device');
  const event = await db.createAnalyticsEvent({ eventType: 'test_event', deviceId: device.id });
  expect(event).toBeDefined();
  expect(event.eventType).toBe('test_event');
  const summary = await db.getAnalyticsSummary();
  const row = summary.find((s: any) => s.eventType === 'test_event');
  expect(row?.count).toBeGreaterThanOrEqual(1);

test('createContact inserts a new contact', async () => {
  const contact = await db.createContact('Tester', '12345');
  expect(contact).toBeDefined();
  expect(contact.name).toBe('Tester');
  expect(contact.phoneNumber).toBe('12345');
});
