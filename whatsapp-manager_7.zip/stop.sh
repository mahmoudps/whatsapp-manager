#!/bin/bash

echo "🛑 إيقاف WhatsApp Manager..."

# إيقاف الحاويات
docker-compose down

echo "✅ تم إيقاف النظام"
